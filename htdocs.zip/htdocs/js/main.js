/*Potencia*/
const rango = document.querySelector("#rango")
const texto = document.querySelector("#texto")

rango.oninput = () => {
    texto.innerHTML = rango.value
}

/* Sensibilidad*/
const ranger = document.querySelector("#ranger")
const text = document.querySelector("#text")

ranger.oninput = () => {
    text.innerHTML = ranger.value
}

/* Rango */
document.getElementById("radio").checked = true;


/*Distancia minima*/
document.getElementById("myCheck").checked = true;


/* Calibración */
function filterFloat(evt,input){
    // Backspace = 8, Enter = 13, ‘0′ = 48, ‘9′ = 57, ‘.’ = 46, ‘-’ = 43
    var key = window.Event ? evt.which : evt.keyCode;    
    var chark = String.fromCharCode(key);
    var tempValue = input.value+chark;
    if(key >= 48 && key <= 57){
        if(filter(tempValue)=== false){
            return false;
        }else{       
            return true;
        }
    }else{
          if(key == 8 || key == 13 || key == 0) {     
              return true;              
          }else if(key == 46){
                if(filter(tempValue)=== false){
                    return false;
                }else{       
                    return true;
                }
          }else{
              return false;
          }
    }
}
function filter(__val__){
    var preg = /^([0-9]+\.?[0-9]{0,1})$/; 
    if(preg.test(__val__) === true){
        return true;
    }else{
       return false;
    }
    
}

/* Pulsos */
document.getElementById('-1234').checked = true;

/* TVG */
const tvg = document.getElementById("1234").checked = true;
